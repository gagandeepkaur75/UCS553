import java.util.Scanner;

class Q2_Alphabet {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a character: ");
        char ch = sc.next().charAt(0);

        if ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')) {
            System.out.println("It is an Alphabet");
        } else {
            System.out.println("It is not an Alphabet");
        }

        sc.close();
    }
}