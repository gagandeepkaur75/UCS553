package course.main;

import course.model.Course;
import course.service.CourseRegistrationService;
import java.util.HashSet;

public class Main {

    public static void main(String[] args) {

        CourseRegistrationService service =
                new CourseRegistrationService();

        // Create courses
        Course c1 = new Course("CSE101", "Java Programming", 2);
        Course c2 = new Course("CSE201", "Advanced Java", 3);

        // Add prerequisite
        c2.addPrerequisite("CSE101");

        // Store courses in HashMap
        service.addCourse(c1);
        service.addCourse(c2);

        // Students with no completed courses
        HashSet<String> noPrerequisites = new HashSet<>();

        System.out.println("\n--- Registration Requests ---");

        service.registerStudent("CSE101", "S101", noPrerequisites);
        service.registerStudent("CSE101", "S102", noPrerequisites);
        service.registerStudent("CSE101", "S103", noPrerequisites);

        // Try registering without completing prerequisite
        service.registerStudent("CSE201", "S104", noPrerequisites);

        System.out.println("\n--- Drop a Student ---");

        // S101 drops CSE101, so S103 gets promoted
        service.dropStudent("CSE101", "S101");

        System.out.println("\n--- Register After Prerequisite ---");

        HashSet<String> completedCourses = new HashSet<>();
        completedCourses.add("CSE101");

        service.registerStudent("CSE201", "S101", completedCourses);

        System.out.println("\n--- Final Course Details ---");

        service.displayAllCourses();
    }
}