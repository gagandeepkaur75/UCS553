package course.service;

import course.model.Course;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class CourseRegistrationService {

    private HashMap<String, Course> courses;

    public CourseRegistrationService() {
        courses = new HashMap<>();
    }

    public void addCourse(Course course) {
        courses.put(course.getCourseCode(), course);
        System.out.println("Course added: " + course.getCourseCode());
    }

    public void registerStudent(
            String courseCode,
            String studentId,
            Set<String> completedCourses) {

        Course course = courses.get(courseCode);

        if (course == null) {
            System.out.println("Course not found: " + courseCode);
            return;
        }

        if (course.getEnrolledStudents().contains(studentId)) {
            System.out.println(studentId + " is already enrolled.");
            return;
        }

        if (course.getWaitlist().contains(studentId)) {
            System.out.println(studentId + " is already on the waitlist.");
            return;
        }

        if (!completedCourses.containsAll(course.getPrerequisites())) {
            System.out.println(studentId + " cannot register for "
                    + courseCode + ". Prerequisites not completed.");
            return;
        }

        if (course.hasSeat()) {
            course.getEnrolledStudents().add(studentId);

            System.out.println(studentId + " enrolled in "
                    + courseCode);
        } else {
            course.getWaitlist().addLast(studentId);

            System.out.println(studentId + " added to waitlist for "
                    + courseCode);
        }
    }

    public void dropStudent(String courseCode, String studentId) {

        Course course = courses.get(courseCode);

        if (course == null) {
            System.out.println("Course not found: " + courseCode);
            return;
        }

        if (!course.getEnrolledStudents().remove(studentId)) {
            System.out.println(studentId + " is not enrolled.");
            return;
        }

        System.out.println(studentId + " dropped " + courseCode);

        promoteWaitlistedStudent(course);
    }

    private void promoteWaitlistedStudent(Course course) {

        if (course.hasSeat() && !course.getWaitlist().isEmpty()) {

            String studentId = course.getWaitlist().removeFirst();

            course.getEnrolledStudents().add(studentId);

            System.out.println(studentId
                    + " promoted from waitlist to enrolled students.");
        }
    }

    public void displayCourse(String courseCode) {

        Course course = courses.get(courseCode);

        if (course == null) {
            System.out.println("Course not found.");
            return;
        }

        course.displayDetails();
    }

    public void displayAllCourses() {

        for (Course course : courses.values()) {
            System.out.println("\n--------------------");
            course.displayDetails();
        }
    }
}