
package media.main;

import media.model.Song;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.HashSet;

public class MediaPlayer {

    public static void main(String[] args) {

        LinkedList<Song> playlist = new LinkedList<>();
        LinkedList<Song> history = new LinkedList<>();

        // Add songs to playlist
        playlist.add(new Song("Perfect", "Ed Sheeran"));
        playlist.add(new Song("Shape of You", "Ed Sheeran"));
        playlist.add(new Song("Believer", "Imagine Dragons"));
        playlist.add(new Song("Perfect", "Ed Sheeran"));

        // Priority insertion at front
        playlist.addFirst(new Song("On My Way", "Alan Walker"));

        // Insert a song at a specific position
        playlist.add(2, new Song("Faded", "Alan Walker"));

        System.out.println("Original Playlist:");
        displayPlaylist(playlist);

        // Remove duplicate songs
        HashSet<String> seenSongs = new HashSet<>();

        playlist.removeIf(song ->
            !seenSongs.add(song.getSongName() + "|" + song.getArtist())
        );

        System.out.println("\nPlaylist After Removing Duplicates:");
        displayPlaylist(playlist);

        // Simulate playing songs and track history
        history.addFirst(playlist.get(0));
        history.addFirst(playlist.get(1));
        history.addFirst(playlist.get(2));

        System.out.println("\nRecently Played (Most Recent First):");
        displayPlaylist(history);

        // Forward navigation
        System.out.println("\nForward Navigation:");
        ListIterator<Song> iterator = playlist.listIterator();

        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }

        // Backward navigation
        System.out.println("\nBackward Navigation:");

        while (iterator.hasPrevious()) {
            System.out.println(iterator.previous());
        }
    }

    public static void displayPlaylist(LinkedList<Song> songs) {
        for (Song song : songs) {
            System.out.println(song);
        }
    }
}
