package media.model;

public class Song {

    private String songName;
    private String artist;

    public Song(String songName, String artist) {
        this.songName = songName;
        this.artist = artist;
    }

    public String getSongName() {
        return songName;
    }

    public String getArtist() {
        return artist;
    }

    @Override
    public String toString() {
        return songName + " - " + artist;
    }
}