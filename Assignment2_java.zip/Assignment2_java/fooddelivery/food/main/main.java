package food.main;

import food.model.FoodOrder;
import food.model.RegularOrder;
import food.model.PremiumOrder;
import food.service.Discountable;
import food.utility.OrderUtility;

public class Main {

    public static void main(String[] args) {

        FoodOrder.setRestaurantName("Food Paradise");

        FoodOrder[] orders = new FoodOrder[6];

        orders[0] = new RegularOrder(101, "Gagandeep", 500);
        orders[1] = new PremiumOrder(102, "Simran", 800);
        orders[2] = new RegularOrder(103, "Karan", 600);
        orders[3] = new PremiumOrder(104, "Aman", 1000);
        orders[4] = new RegularOrder(105, "Neha", 700);
        orders[5] = new PremiumOrder(106, "Riya", 1200);

        System.out.println("=================================");
        System.out.println("       " + FoodOrder.getRestaurantName());
        System.out.println("=================================");

        for (FoodOrder order : orders) {

            System.out.println("\n---------- BILL ----------");

            OrderUtility.generateOrderSummary(order);

            Discountable discountable = (Discountable) order;

            double discount = discountable.applyDiscount();

            double deliveryCharge = order.calculateDeliveryCharge();

            double finalAmount =
                    order.getAmount() - discount + deliveryCharge;

            System.out.println("Discount: Rs. " + discount);
            System.out.println("Delivery Charge: Rs. " + deliveryCharge);
            System.out.println("Final Payable Amount: Rs. " + finalAmount);
        }

        System.out.println("\n=================================");
        FoodOrder.displayTotalOrders();
        System.out.println("=================================");
    }
}