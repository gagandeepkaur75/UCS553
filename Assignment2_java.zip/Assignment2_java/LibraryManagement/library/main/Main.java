package library.main;

import library.model.LibraryResource;
import library.model.Book;
import library.model.DigitalResource;
import library.service.Printable;
import library.util.InputValidator;

public class Main {

    public static void main(String[] args) {

        LibraryResource.setLibraryName("Central University Library");

        LibraryResource[] resources = new LibraryResource[5];

        resources[0] = new Book(101, "Java Programming", "James Gosling");
        resources[1] = new DigitalResource(102, "Python Course", "Guido van Rossum");
        resources[2] = new Book(103, "Data Structures", "Mark Allen");
        resources[3] = new DigitalResource(104, "Cloud Computing", "Andrew Tanenbaum");
        resources[4] = new Book(105, "Operating Systems", "Abraham Silberschatz");

        int[] overdueDays = {5, 10, 3, 7, 2};

        double totalFine = 0;

        System.out.println("======================================");
        System.out.println("      " + LibraryResource.getLibraryName());
        System.out.println("======================================");

        for (int i = 0; i < resources.length; i++) {

            System.out.println("\n---------- RESOURCE ----------");

            Printable printable = (Printable) resources[i];
            printable.printDetails();

            int days = overdueDays[i];

            if (InputValidator.validateResourceId(
                    resources[i].getResourceId())
                    && InputValidator.validateFineDays(days)) {

                double fine = resources[i].calculateFine(days);

                System.out.println("Overdue Days: " + days);
                System.out.println("Fine: Rs. " + fine);

                totalFine = totalFine + fine;
            }
        }

        System.out.println("\n======================================");
        System.out.println("Total Fine of All Resources: Rs. " + totalFine);
        System.out.println("======================================");

        LibraryResource.displayTotalResources();
    }
}