
import java.util.Optional;
import java.util.Objects;

class Result<T extends Number> {

    private T[] marks;

    public Result(T[] marks) {
        this.marks = Objects.requireNonNull(marks, "Marks cannot be null");
    }

    public double calculateAverage() {
        double sum = 0;

        for (int i = 0; i < marks.length; i++) {
            sum = sum + marks[i].doubleValue();
        }

        return sum / marks.length;
    }

    public double calculatePercentage(double totalMaximumMarks) {
        double sum = 0;

        for (int i = 0; i < marks.length; i++) {
            sum = sum + marks[i].doubleValue();
        }

        return (sum / totalMaximumMarks) * 100;
    }

    public boolean hasPassed(double threshold) {
        return calculatePercentage(500) >= threshold;
    }

    public Optional<T[]> getMarks() {
        return Optional.ofNullable(marks);
    }
}

public class Q3 {

    public static void main(String[] args) {

        Double[] studentMarks = {80.0, 75.0, 90.0, 85.0, 70.0};

        Result<Double> result = new Result<>(studentMarks);

        result.getMarks().ifPresent(marks -> {
            System.out.println("Student Marks:");

            for (Double mark : marks) {
                System.out.println(mark);
            }
        });

        System.out.println("Average: " + result.calculateAverage());
        System.out.println("Percentage: "
                + result.calculatePercentage(500) + "%");

        if (result.hasPassed(40)) {
            System.out.println("Result: Pass");
        } else {
            System.out.println("Result: Fail");
        }
    }
}
