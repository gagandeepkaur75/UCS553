
import java.util.Optional;

public class Q2 {

    public static void main(String[] args) {

        // 1. Create an Optional containing an email
        Optional<String> email = Optional.of("student@gmail.com");

        // 2. Create an empty Optional
        Optional<String> emptyEmail = Optional.empty();

        // 3. Display email using ifPresent()
        System.out.println("Student Email:");
        email.ifPresent(e -> System.out.println(e));

        // 4. Use orElse() to provide a default email
        String defaultEmail =
                emptyEmail.orElse("default@gmail.com");

        System.out.println("Default Email: " + defaultEmail);

        // 5. Use orElseThrow() for a missing email
        try {
            String missingEmail = emptyEmail.orElseThrow(
                    () -> new RuntimeException("Email is missing!")
            );

            System.out.println("Email: " + missingEmail);

        } catch (RuntimeException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}
