
import java.util.Optional;
import java.util.Objects;

class GenericUtility {

    // Check whether two objects are equal
    public static <T> boolean isEqual(T a, T b) {
        return Objects.equals(a, b);
    }

    // Return value or default value
    public static <T> T getDefault(
            Optional<T> value, T defaultValue) {
        return value.orElse(defaultValue);
    }

    // Find the larger of two comparable objects
    public static <T extends Comparable<T>> T max(T a, T b) {
        if (a.compareTo(b) >= 0) {
            return a;
        } else {
            return b;
        }
    }

    // Check whether an object is null
    public static boolean isNull(Object obj) {
        return Objects.isNull(obj);
    }
}

public class Q5 {

    public static void main(String[] args) {

        System.out.println("Strings Equal: "
                + GenericUtility.isEqual("Java", "Java"));

        System.out.println("Integers Equal: "
                + GenericUtility.isEqual(10, 20));

        Optional<String> name = Optional.empty();

        System.out.println("Default Name: "
                + GenericUtility.getDefault(name, "Unknown"));

        System.out.println("Maximum Integer: "
                + GenericUtility.max(25, 40));

        System.out.println("Maximum String: "
                + GenericUtility.max("Apple", "Banana"));

        String value = null;

        System.out.println("Is Null: "
                + GenericUtility.isNull(value));
    }
}
