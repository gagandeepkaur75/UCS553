
public class Q1 {

    public static <T extends Number> double calculateSum(T[] array) {

        double sum = 0;

        for (int i = 0; i < array.length; i++) {
            sum = sum + array[i].doubleValue();
        }

        return sum;
    }

    public static void main(String[] args) {

        Integer[] intArray = {10, 20, 30, 40};
        Float[] floatArray = {1.5f, 2.5f, 3.5f};
        Double[] doubleArray = {10.5, 20.5, 30.5};

        System.out.println("Sum of Integer array: "
                + calculateSum(intArray));

        System.out.println("Sum of Float array: "
                + calculateSum(floatArray));

        System.out.println("Sum of Double array: "
                + calculateSum(doubleArray));
    }
}
