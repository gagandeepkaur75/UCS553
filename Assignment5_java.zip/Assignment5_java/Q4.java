
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.Scanner;

public class Q4 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter event name: ");
        String eventName = sc.nextLine();

        System.out.print("Enter event date (YYYY-MM-DD): ");
        LocalDate eventDate = LocalDate.parse(sc.nextLine());

        System.out.print("Enter start time (HH:MM): ");
        LocalTime startTime = LocalTime.parse(sc.nextLine());

        System.out.print("Enter venue (or press Enter to skip): ");
        String venueInput = sc.nextLine();

        Optional<String> venue = venueInput.trim().isEmpty()
                ? Optional.empty()
                : Optional.of(venueInput);

        LocalDate today = LocalDate.now();

        System.out.println("\n--- Event Details ---");
        System.out.println("Event Name: " + eventName);
        System.out.println("Event Date: " + eventDate);
        System.out.println("Start Time: " + startTime);
        System.out.println("End Time: " + startTime.plusHours(2));

        System.out.println("Venue: "
                + venue.orElse("Venue not specified"));

        if (eventDate.isAfter(today)) {
            System.out.println("Event Status: Future");
            System.out.println("Days Remaining: "
                    + ChronoUnit.DAYS.between(today, eventDate));
        } else if (eventDate.isEqual(today)) {
            System.out.println("Event Status: Today");
            System.out.println("Days Remaining: 0");
        } else {
            System.out.println("Event Status: Past");
            System.out.println("Days Remaining: 0");
        }

        sc.close();
    }
}
